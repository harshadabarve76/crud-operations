﻿using Microsoft.AspNetCore.Mvc;

namespace CRUD_OPERATIONS.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
