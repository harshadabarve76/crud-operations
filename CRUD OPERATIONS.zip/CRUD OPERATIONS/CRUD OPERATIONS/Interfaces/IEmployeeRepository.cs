﻿using CRUD_OPERATIONS.Models;

namespace CRUD_OPERATIONS.Interfaces
{
    public interface IEmployeeRepository
    {
        Task<IEnumerable<Employee>> GetAllAsync();
        Task<Employee?> GetByIdAsync(int EmployeeId);
         
        Task InsertAsync(Employee employee);
        Task UpdateAsync(Employee employee);
        Task DeleteAsync(int EmployeeId);

        Task SaveAsync();
    }
}
