
USE  EMPLOYEEDB;
insert into Departments values ('Salesforce'),
('Digital'),
('Technical Support'),
('Service now'),
('Managment');


insert into Employees values ('Harshada Barve','harshadabarve76@gmail.com','Cloud Engineer',1),
('Suwaiba Sayyed','suwaibasayyed@gmail.com','Software Engineer',2),
('Danish Sayyed','danishsayyed@gmail.com','Cloud Architect',4),
('Gauri Kolhe', 'gaurikolhe@gmail.com','Linux Engineer',3),
('Ujjwal Jejurkar','ujjwaljejurkar@gmail.com','HR',5);

select * from Departments
select * from Employees
